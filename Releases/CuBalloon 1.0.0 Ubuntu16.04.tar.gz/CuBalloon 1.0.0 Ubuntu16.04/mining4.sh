#!/bin/bash
./cuballoon -o stratum+tcp://deft.mining4.co.uk:3339 -u dEgaowDNLGs4khPJYCjJ12r9iLusKAn8KW --cuda_threads 64 --cuda_blocks 48 --cuda_sync 0
